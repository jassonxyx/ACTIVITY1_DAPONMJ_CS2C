let age = 19;
let EnteryourAge = age

console.log("Enter Your Age:", EnteryourAge);
if (age < 13){console.log("You are a child.");}
else if(age <20){console.log("You are a teenager.")}
else
{console.log("You are an  adult")}