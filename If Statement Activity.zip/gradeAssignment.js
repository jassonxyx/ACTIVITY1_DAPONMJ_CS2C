let grade = 88;
let EnteryourScore = grade

console.log("Enter your score:", EnteryourScore);

if (grade >= 90) { console.log("Excellent"); }
else if (grade >= 80) { console.log("Good"); }
else { console.log("Needs improvement"); }